package com.google.testing.stepsdefinitions;

import org.openqa.selenium.WebDriver;

import com.google.testing.tasks.EntrarAGoogle;
import com.google.testing.ui.PaginaDeInicio;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.thucydides.core.annotations.Managed;

public class BuscarEnGoogleStepsDefinitions {
	PaginaDeInicio paginadeinicio;

	@Managed(driver = "chrome")
	WebDriver SuNavegador;
	
	Actor Melissa = Actor.named("Melissa");
	
	@Before
	public void setUp() {
		Melissa.can(BrowseTheWeb.with(SuNavegador));
	}
	
	@Given("Melissa entro a Google")
	public void adrianEntroAGoogle() {
		Melissa.attemptsTo(EntrarAGoogle.En(paginadeinicio));
	}

	@When("Melissa busca la palabra (.*)")
	public void adrianBuscaLaPalabra(String string) {
	}

	@Then("Melissa valida que el titulo de la ventana contenga la palabra (.*)")
	public void adrianValidaQueElTituloDeLaVentanaContengaLaPalabra(String string) {
	}

}
