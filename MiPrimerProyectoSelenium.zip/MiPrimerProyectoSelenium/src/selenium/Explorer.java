package selenium;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class Explorer {
	
	public static void main (String[]args) throws IOException, InterruptedException, ATUTestRecorderException {
		
		DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		Date date = new Date();
		  
		 ATUTestRecorder  recorder = new ATUTestRecorder("C:\\Selenium\\ScriptVideos\\","TestVideo-"+dateFormat.format(date),false);
		 
		 recorder.start();
		 
		//TODO Auto-generated method stub
		//Crea el comando que controla el navegador
		System.setProperty("webdriver.ie.driver", "C:\\Selenium\\IEDriverServer_Win32_3.11.1\\IEDriverServer.exe");
		
		//Crea "robot"
		WebDriver Melissa = new InternetExplorerDriver();
		
		//Tiempo
		Melissa.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		
		//Ir a una url
		Melissa.get("http://www.google.com");
		
		//Maximiza ventana
		Melissa.manage().window().maximize();
		
		//Selecciona el elemento a interacturar
		//Melissa.findElement(By.xpath("//input[@name='q']")).sendKeys("pinterest");
		Melissa.findElement(By.name("q")).sendKeys("pinterest");
		Melissa.findElement(By.name("q")).sendKeys(Keys.ENTER);
		Melissa.findElement(By.xpath("//cite[contains(text(),'https://co.pinterest.com/')]")).sendKeys(Keys.ENTER);
		Melissa.findElement(By.xpath("//input[@id='email']")).sendKeys("balvinmelissa@gmail.com");
		Melissa.findElement(By.xpath("//input[@id='password']")).sendKeys("balvin");
		
		//Captura
		File scrFile = ((TakesScreenshot)Melissa).getScreenshotAs(OutputType.FILE); 
		FileUtils.copyFile(scrFile, new File("c:\\Selenium\\ScreenShots\\screenshot1"+dateFormat.format(date)+".png"));
		recorder.stop();
		
		//Cierra ventana
		Melissa.quit();
		
		recorder.stop();
	}

}
