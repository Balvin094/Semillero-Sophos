package com.booking.testing.stepsdefinitions;


import org.openqa.selenium.WebDriver;

import com.booking.testing.exceptions.UnableToConnect;
import com.booking.testing.questions.ElResultado;
import com.booking.testing.task.BuscarDestino;
import com.booking.testing.task.DaClickBotonBuscar;
import com.booking.testing.task.EntrarABooking;
import com.booking.testing.task.SeleccionaFecha;
import com.booking.testing.task.SeleccionarCantidadDeAdultos;
import com.booking.testing.task.SeleccionarFecha;
import com.booking.testing.ui.PaginaDeInicio;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.thucydides.core.annotations.Managed;
import static org.hamcrest.Matchers.equalTo;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;

public class BookingStepsDefinitions {
	PaginaDeInicio paginadeinicio; 
	
	@Managed(driver = "chrome")
	WebDriver SuNavegador;
	
	Actor Melissa = Actor.named("Melissa");
	
	
	@Before
	public void setUp() {
		Melissa.can(BrowseTheWeb.with(SuNavegador));
		SuNavegador.manage().window().maximize();
	}
	
	@Given("Melissa entra la pagina de booking")
	public void melissaEntraLaPaginaDeBooking() {
		Melissa.attemptsTo(EntrarABooking.En(paginadeinicio));
	}


	@When("Melissa busca los alojamientos en un destino")
	public void melissaBuscaLosAlojamientosEnUnDestino()  {
		Melissa.attemptsTo(BuscarDestino.en());
		Melissa.attemptsTo(SeleccionarFecha.ida());
		Melissa.attemptsTo(SeleccionaFecha.regreso());
		Melissa.attemptsTo(SeleccionarCantidadDeAdultos.en());
		Melissa.attemptsTo(DaClickBotonBuscar.en());
		
	    
	}

	@Then("Melissa valida que los alojamientos sean para ese destino")
	public void melissaValidaQueLosAlojamientosSeanParaEseDestino() {
		Melissa.should(seeThat(ElResultado.en(), equalTo("Las 3 razones para visitar este lugar: playas, playas de arena y relax"))
													.orComplainWith(UnableToConnect.class, UnableToConnect.getConecctionMessage()));
	}

}
