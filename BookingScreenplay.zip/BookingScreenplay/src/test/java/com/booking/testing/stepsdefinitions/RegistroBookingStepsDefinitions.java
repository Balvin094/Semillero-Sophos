package com.booking.testing.stepsdefinitions;


import java.util.List;

import org.openqa.selenium.WebDriver;

import com.booking.testing.models.RegistroDatos;
import com.booking.testing.questions.Resultado;
import com.booking.testing.task.DarClickEnEmpezar;
import com.booking.testing.task.EntrarABooking;
import com.booking.testing.task.EntrarARegistrarse;
import com.booking.testing.task.Registrarse;
import com.booking.testing.ui.PaginaDeInicio;



import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.thucydides.core.annotations.Managed;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.equalTo;

public class RegistroBookingStepsDefinitions {
	PaginaDeInicio paginadeinicio; 
	
	@Managed(driver = "chrome")
	WebDriver SuNavegador;
	
	Actor Melissa = Actor.named("Melissa");
	
	
	@Before
	public void setUp() {
		Melissa.can(BrowseTheWeb.with(SuNavegador));
		SuNavegador.manage().window().maximize();
	}
	
	@Given("Melissa entra a la pagina de booking")
	public void melissaEntraALaPaginaDeBooking() throws Exception {
		Melissa.wasAbleTo(EntrarABooking.En(paginadeinicio));
		Melissa.attemptsTo(EntrarARegistrarse.en());
	}


	@When("Ella ingresa los datos para registrarse")
	public void ellaIngresaLosDatosParaRegistrarse(List<RegistroDatos> resgistroDatos) throws Exception {
	    Melissa.attemptsTo(Registrarse.en(resgistroDatos));
	    Melissa.attemptsTo(DarClickEnEmpezar.en());
	    Melissa.remember("resultadoprueba", resgistroDatos.get(0).getExpected());
	}

	@Then("Ella valida que su registro fue exitoso")
	public void ellaValidaQueSuRegistroFueExitoso() throws Exception {
	   Melissa.should(seeThat(Resultado.en(), equalTo(Melissa.recall("resultadoprueba"))));
	}

}
