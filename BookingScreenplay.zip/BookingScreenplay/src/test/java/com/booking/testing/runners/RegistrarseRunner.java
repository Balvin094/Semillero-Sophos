package com.booking.testing.runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;

//Se ejecutara un test con junit RunWith - Clase que ejecutara el proyecto, test y genera informe
@RunWith(CucumberWithSerenity.class)
//Que se va a ejecutar y se da la ubicacion de donde estan los archivos y donde van a quedar 
@CucumberOptions(features = "src/test/java/com/booking/testing/"
		+ "features/RegistrarseBooking.feature",glue = "com.booking.testing"
				+ ".stepsdefinitions", snippets = SnippetType.CAMELCASE)
public class RegistrarseRunner {

}
