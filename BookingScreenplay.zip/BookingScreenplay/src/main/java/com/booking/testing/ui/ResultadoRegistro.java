package com.booking.testing.ui;

import org.openqa.selenium.By;

import net.serenitybdd.screenplay.targets.Target;

public class ResultadoRegistro {
	
	public static final Target resultadoDeregistro = Target.the("Texto de registro")
			.located(By.xpath("//div[@id='login_name_register-error']"));

}
