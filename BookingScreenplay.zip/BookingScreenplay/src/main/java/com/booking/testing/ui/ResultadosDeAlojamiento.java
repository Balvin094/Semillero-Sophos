package com.booking.testing.ui;

import org.openqa.selenium.By;

import net.serenitybdd.screenplay.targets.Target;

public class ResultadosDeAlojamiento {
	
	public static final Target resultadosDestino = Target.the("Texto de los alojamientos")
			.located(By.xpath("//p[@class='sr-header-endorsments']"));
}
