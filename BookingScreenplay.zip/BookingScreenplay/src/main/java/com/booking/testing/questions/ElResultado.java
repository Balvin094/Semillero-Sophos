package com.booking.testing.questions;

import  static com.booking.testing.ui.ResultadosDeAlojamiento.resultadosDestino;


import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class ElResultado implements Question<String> {

	@Override
	public String answeredBy(Actor actor) {
		// TODO Auto-generated method stub
		return Text.of(resultadosDestino).viewedBy(actor).asString();
	}

	public static ElResultado en() {
		// TODO Auto-generated method stub
		return new ElResultado();
	}

}
