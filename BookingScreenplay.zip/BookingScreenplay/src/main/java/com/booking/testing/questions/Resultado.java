package com.booking.testing.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

import static com.booking.testing.ui.ResultadoRegistro.resultadoDeregistro;

public class Resultado implements Question<String>{

	
	@Override
	public String answeredBy(Actor actor) {
		// TODO Auto-generated method stub
		return Text.of(resultadoDeregistro).viewedBy(actor).asString();
	}

	public static Resultado en() {
		// TODO Auto-generated method stub
		return new Resultado();
	}

}
