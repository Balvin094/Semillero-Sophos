package com.booking.testing.task;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Enter;

import  static net.serenitybdd.screenplay.Tasks.instrumented;

import java.util.List;

import com.booking.testing.models.RegistroDatos;
import com.booking.testing.ui.RegistroBooking;

public class Registrarse implements Task{
	
	private List<RegistroDatos> registroDatos;
	
	public Registrarse(List<RegistroDatos> registroDatos) {
		this.registroDatos= registroDatos;
	}

	@Override
	public <T extends Actor> void performAs(T actor) {
		// TODO Auto-generated method stub
		actor.attemptsTo(Enter.theValue(registroDatos.get(0).getUser()).into(RegistroBooking.ingresarEmail));
		
	}

	public static Registrarse en(List<RegistroDatos> registroDatos) {
		// TODO Auto-generated method stub
		return instrumented(Registrarse.class, registroDatos);
	}

}
