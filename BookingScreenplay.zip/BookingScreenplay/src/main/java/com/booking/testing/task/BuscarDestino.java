package com.booking.testing.task;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Enter;

import  static net.serenitybdd.screenplay.Tasks.instrumented;

import com.booking.testing.ui.PaginaDeInicio;

public class BuscarDestino implements Task{


	@Override
	public <T extends Actor> void performAs(T actor) {
		// TODO Auto-generated method stub
		actor.attemptsTo(Enter.theValue("Cancun").into(PaginaDeInicio.getCampoADondeVas()));
		
	}
	
	public static BuscarDestino en() {
		// TODO Auto-generated method stub
		return instrumented(BuscarDestino.class);
	}

}
