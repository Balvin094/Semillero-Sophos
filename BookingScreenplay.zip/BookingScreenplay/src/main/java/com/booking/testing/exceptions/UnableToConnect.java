package com.booking.testing.exceptions;

public class UnableToConnect extends AssertionError {
	
	private static final String NO_PUEDE_CONECTARSE = "incapaz de conectarse";
	
	public static String getConecctionMessage() {
		return NO_PUEDE_CONECTARSE;
	}
	
	public UnableToConnect(String message, Throwable cause) {
		super(message, cause);
	}

}
