package com.booking.testing.ui;

import org.openqa.selenium.By;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://www.booking.com/country/mx")
public class PaginaDeInicio extends PageObject {

	 private static final Target campoADondeVas = Target.the("Campo de busqueda del destino").located(By.xpath("//input[@id='ss']"));
	 
	 public static Target getCampoADondeVas() {
		 return campoADondeVas;
	 }
	 
	 public static final Target fechaCheckIn = Target.the("Fecha de ida").located(By.xpath("//div[@class='bui-calendar__content']//tr[4]/td[contains(.,'12')]"));
	 

	 public static final Target fechaCkeckOut = Target.the("Fecha de regreso").located(By.xpath("//div[@class='bui-calendar__content']//tr[4]/td[contains(.,'14')]"));

	 public static final Target campoCantidadDeAdultos = Target.the("Abrir ventana para seleccionar adultos").located(By.xpath("//label[@id='xp__guests__toggle']"));
	 
	 public static final Target seleccionarCantidadAdultos = Target.the("Seleccionar la cantidad de adultos").located(By.xpath("//div[@class='sb-group__field sb-group__field-adults']//span[@class='bui-button__text'][contains(text(),'+')]"));

	 public static final Target darClickBotonBuscar = Target.the("Dar click en el boton buscar").located(By.xpath("//button[contains(@class,'sb-searchbox__button')]"));
}
