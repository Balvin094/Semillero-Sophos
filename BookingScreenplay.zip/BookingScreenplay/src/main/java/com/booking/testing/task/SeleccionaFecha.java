package com.booking.testing.task;

import com.booking.testing.ui.PaginaDeInicio;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import  static net.serenitybdd.screenplay.Tasks.instrumented;

public class SeleccionaFecha implements Task{

	@Override
	public <T extends Actor> void performAs(T actor) {
		// TODO Auto-generated method stub
		actor.attemptsTo(Click.on(PaginaDeInicio.fechaCkeckOut));
		
	}
	
	public static SeleccionaFecha regreso() {
		// TODO Auto-generated method stub
		return instrumented(SeleccionaFecha.class);
	}

	

}
