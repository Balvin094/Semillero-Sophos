package com.booking.testing.models;

public class RegistroDatos {
	
	private String user;
	private String expected;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	public String getExpected() {
		return expected;
	}
	public void setExpected(String expected) {
		this.expected = expected;
	}
	
	
	

}
