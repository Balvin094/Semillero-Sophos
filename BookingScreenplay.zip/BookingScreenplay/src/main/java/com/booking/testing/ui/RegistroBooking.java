package com.booking.testing.ui;

import org.openqa.selenium.By;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;


public class RegistroBooking extends PageObject{
	
	public static final Target darClickEnHazteUnaCuenta = Target.the("Dar click en hazte una cuenta")
			.located(By.xpath("//span[contains(text(),'Hazte una cuenta')]"));
	
	public static final Target ingresarEmail = Target.the("Ingresar el email").located(By.xpath("//input[@id='login_name_register']"));
	
	public static final Target darClickEnEmpezar = Target.the("Dar click en empezar").located(By.xpath("//span[@class='bui-button__text']"));

}
