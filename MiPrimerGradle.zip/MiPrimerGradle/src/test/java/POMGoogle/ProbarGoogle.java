package POMGoogle;

import static POMGoogle.Google.escribirEnElCampoDeBusqueda;
import static POMGoogle.Google.darClickEnBotonBuscar;
import static POMGoogle.Google.abrirPaginaInicialDeGoogle;
import static POMGoogle.Google.seleccionarLaPaginaBuscada;


import org.junit.Test;



public class ProbarGoogle {

	@Test
	public void probarBusquedaEnGoogle() {
		 abrirPaginaInicialDeGoogle();
		 escribirEnElCampoDeBusqueda("Sophos Solutions");
		 darClickEnBotonBuscar();
		 seleccionarLaPaginaBuscada();
	}

}
