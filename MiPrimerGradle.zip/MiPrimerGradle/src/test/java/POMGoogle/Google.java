package POMGoogle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Google {
	
	static WebDriver Melissa;
	static By campodeBusqueda=By.name("q");
	static By botonBuscar =By.xpath("//div[@class='FPdoLc VlcLAe']//input[@name='btnK']");
	static By seleccionarOpcion=By.xpath("//cite[contains(text(),'www.sophossolutions.com/')]");
	
	 
	 
	public static  void escribirEnElCampoDeBusqueda(String cadenabuscar) {
		 Melissa.findElement(campodeBusqueda).sendKeys(cadenabuscar);
		 
	}
	
	public  static void darClickEnBotonBuscar() {
		Melissa.findElement(botonBuscar).click();
		
	}
	
	public static void seleccionarLaPaginaBuscada() {
		Melissa.findElement(seleccionarOpcion).click();
	}
	
	public static void abrirPaginaInicialDeGoogle() {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		 Melissa= new ChromeDriver();
		 Melissa.manage().window().maximize();
		 Melissa.get("http://www.google.com");
	}
	
	

}
