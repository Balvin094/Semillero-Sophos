package POMBooking;


import static POMBooking.Booking.abrirPaginaDeBooking;
import static POMBooking.Booking.elegirDestino;
/*import static POMBooking.Booking.seleccionarFecha;
import static POMBooking.Booking.seleccionarMes;
import static POMBooking.Booking.seleccionarElDia;*/
import static POMBooking.Booking.seleccionarCantidadPersonas;
import static POMBooking.Booking.seleccionarCantidadDeAdultos;
import static POMBooking.Booking.darClickEnElBotonBuscar;
import static POMBooking.Booking.seleccionarOpcionAlojamiento;
import static POMBooking.Booking.selecionarCantidadDeNi�os;
import static POMBooking.Booking.seleccionarEdadDelNi�o;
import static POMBooking.Booking.cerrarNavegador;
//import static POMBooking.Booking.validarCampoDestino;
import static POMBooking.Booking.seleccionarFechaCheckIn;
import static POMBooking.Booking.seleccionarFechaCheckOut;

import java.io.IOException;



import org.junit.Test;
import org.openqa.selenium.WebDriver;



public class ProbarBooking {

	static WebDriver Melissa;
	
	

	@Test
	public void test() throws InterruptedException, IOException {
		
		abrirPaginaDeBooking();
		elegirDestino();
		seleccionarFechaCheckIn();
		seleccionarFechaCheckOut();
		/*seleccionarFecha();
		seleccionarMes();
		seleccionarElDia();*/
		seleccionarCantidadPersonas();
		seleccionarCantidadDeAdultos();
		selecionarCantidadDeNi�os();
		seleccionarEdadDelNi�o();
		darClickEnElBotonBuscar();
		seleccionarOpcionAlojamiento();
		//validarCampoDestino();
		cerrarNavegador();
		
		
	}

}
