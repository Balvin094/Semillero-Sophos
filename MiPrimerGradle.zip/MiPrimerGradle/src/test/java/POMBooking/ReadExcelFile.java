package POMBooking;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelFile {
	
	//Metodo que permite leer la hoja de excel	
	public void readExcel(String filepath,String sheetName) throws IOException {
		
		//El camino donde va estar el fichero
		File file = new File(filepath);
		
		//Leer los datos del archivo
		FileInputStream inputStream = new FileInputStream(file);
		
		//Donde se guarda el libro de excel, el fichero como tal. el inputStream el archivo de los datos
		XSSFWorkbook newWorbook =new XSSFWorkbook(inputStream);
		
		//El objeto donde se guarda la hoja donde se trabaja
		XSSFSheet newSheet = newWorbook.getSheet(sheetName);
		
		//Cuantas filas de datos tiene el excel		
		int rowCount = newSheet.getLastRowNum()-newSheet.getFirstRowNum();
		
		//Un ciclo para ir leyendo fila por fila en la hoja
		 for (int i = 0; i < rowCount; i++) {
		XSSFRow row = newSheet.getRow(i);
			 
		 //Para recorrer todad las celdas de las filas 
		 for (int j = 0; j < row.getLastCellNum(); j++) {
				  
	  //Valor de la celda e imprimir el caracter para finalizar la linea
		System.out.print(row.getCell(j).getStringCellValue()+"|| ");
			  }

		 }
	}
	
	// permitir leer el valor expecifico de una celda
	public String getCellValue(String sheetName,String filepath,int rowNumber, int cellNumber) throws IOException {
		
		//El camino donde va estar el fichero
		File file = new File(filepath);
		
		//Leer los datos del archivo
		FileInputStream inputStream = new FileInputStream(file);
		
		//Donde se guarda el libro de excel, el fichero como tal. el inputStream el archivo de los datos
		XSSFWorkbook newWorbook =new XSSFWorkbook(inputStream);
		
		//El objeto donde se guarda la hoja donde se trabaja
		XSSFSheet newSheet = newWorbook.getSheet(sheetName);
		
		//La informacion de una celda expecifica, el numero que estamos pasando Columna 
		XSSFRow row = newSheet.getRow(rowNumber);
		
		//El numero que estamos pasando Numero
		XSSFCell cell = row.getCell(cellNumber);
		
		//Devolvemos la informacion
		return cell.getStringCellValue();
	}

	public double getNumericCellValue(String sheetName, String filepath, int rowNumber, int cellNumber) throws IOException {
		
		//El camino donde va estar el fichero
			File file = new File(filepath);
			
		//Leer los datos del archivo
		FileInputStream inputStream = new FileInputStream(file);
		
		//Donde se guarda el libro de excel, el fichero como tal. el inputStream el archivo de los datos
		XSSFWorkbook newWorbook =new XSSFWorkbook(inputStream);
			
		//El objeto donde se guarda la hoja donde se trabaja
		XSSFSheet newSheet = newWorbook.getSheet(sheetName);
			
		//La informacion de una celda expecifica, el numero que estamos pasando Columna 
		XSSFRow row = newSheet.getRow(rowNumber);
			
		//El numero que estamos pasando Numero
		XSSFCell cell = row.getCell(cellNumber);
			
		//Devolvemos la informacion
		return cell.getNumericCellValue();
	}
	}
