package POMBooking;



import java.io.IOException;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import POMBooking.ReadExcelFile;
import POMBooking.WriteExcelFile;


public class Booking {
	
	//Declaramos el robot 
	static WebDriver Melissa;
	//Declaramos el js para hacer visible un elemento
	static JavascriptExecutor js;
	//Declaramos el wait para el tiempo de espera 
	static WebDriverWait wait;
	//Declaracion variable escribir y obtener campos
	static WriteExcelFile escribirArchivo;
	//Declaracion variable leer y obtener campos
	static ReadExcelFile leerArchivo;
	//Declaramos la ruta donde esta el archivo de excel	
	static String rutaArchivoDeExcel = "C:\\Users\\semillero\\Documents\\Prueba.xlsx";
	//Declaracion de variables para asignar el dato del excel
	static String textoABuscar;
	static String resultText;
	static double numEntero;
	
	//Mapeo de los elementos de la pagina
	static By campodeBusqueda=By.xpath("//input[@id='ss']");
	static By seleccionarCalendario=By.xpath("//div[@class='xp__dates-inner']");
	static By fechacheckin=By.xpath("//div[@class='bui-calendar__content']//tr[4]/td[contains(.,'12')]");
	static By fechacheckout=By.xpath("//div[@class='bui-calendar__content']/div[1]//td[contains(.,'16')]");
	static By seleccionarDia=By.xpath("//td[contains(text(),'12')]");
	static By seleccionMes=By.xpath("//div[contains(@class, 'bui-calendar__month')]");
	static By flechasiguiente=By.xpath("//div[contains(@class,'bui-calendar__control bui-calendar__control--next')]");
	static By elegirCantidadDePersonas=By.xpath("//label[@id='xp__guests__toggle']");
	static By cantidadDeAdultos=By.xpath("//div[contains(@class,'sb-group__field sb-group__field-adults')]//button[contains(@class,'bui-button bui-button--secondary bui-stepper__add-button')]");
	static By cantidadDeNi�os=By.xpath("//div[contains(@class,'sb-group__field sb-group-children')]//span[contains(@class,'bui-button__text')][contains(text(),'+')]");
	static By cantidadHabitaciones=By.xpath("//div[contains(@class,'sb-group__field sb-group__field-rooms')]//button[contains(@class,'bui-button bui-button--secondary bui-stepper__add-button')]");
	static By clickEnElBotonBuscar=By.xpath("//button[contains(@class,'sb-searchbox__button')]");
	static By seleccionarElHotel=By.xpath("//span[contains(text(),'Oh! Cancun - The Urban Oasis')]");
	static By reservarHabitacion=By.xpath("//span[@class='b-button__text']");
	static By elegirHabitacion=By.xpath("//div[starts-with(@class='hprt-reservation-cta')]");
	
	
	public static void abrirPaginaDeBooking() {
		
		//Damos la ubicacion del webdriver
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		//Creamos el robot
		 Melissa= new ChromeDriver();
		 //Tiempo de espera 
		  wait = new WebDriverWait (Melissa, 30);
		 //Propiedad para hacer visible un elemento
		  js=(JavascriptExecutor) Melissa;
		 //Maximiza la ventana
		 Melissa.manage().window().maximize();
		 //Vamos a la pagina ingresada
		 Melissa.get("https://www.booking.com/country/mx");
	}
	

	public static  void elegirDestino() throws InterruptedException, IOException {
	//Declara la variable que sea igual a archivo externo de excel
		leerArchivo = new ReadExcelFile();
	//Le damos el valor a buscar en el excel
		textoABuscar = leerArchivo.getCellValue("DatosBooking",rutaArchivoDeExcel , 1, 0);
	//Ingresamos la palabra de busqueda 
		Melissa.findElement(campodeBusqueda).sendKeys(textoABuscar);
	}
	
	/*public static void validarCampoDestino() throws IOException {
		escribirArchivo= new WriteExcelFile();
		String validar= Melissa.findElement(campodeBusqueda).getText();
		escribirArchivo.writeCellValue(rutaArchivoDeExcel, "DatosBooking", 1, 2, validar);
	}*/
	
	public static void seleccionarFechaCheckIn() {
		Melissa.findElement(fechacheckin).click();
	}
	
	public static void seleccionarFechaCheckOut() {
		Melissa.findElement(fechacheckout).click();
	}
	
	 /*public static void seleccionarFecha() {
    	 Melissa.findElement(seleccionarCalendario).click();
     }
  
	
	public static void seleccionarMes() throws IOException, InterruptedException {
    	textoABuscar = leerArchivo.getCellValue("DatosBooking",rutaArchivoDeExcel ,6, 0);
    		int i;
    		boolean mes=true;
    		for(i=0;i<=12;i+=i) {
    			String datoDelMes = Melissa.findElement(seleccionMes).getText();
    			if(datoDelMes.contentEquals(textoABuscar) && mes==true) {
    				i=12;
    				mes=false;
    			}else {
    				Thread.sleep(3000);
    	    		Melissa.findElement(flechasiguiente).click();
    			}
    		}
     }
	
	public static void seleccionarElDia() throws IOException {
   	 numEntero=  leerArchivo.getNumericCellValue("DatosBooking", "C:\\Users\\semillero\\Documents\\Prueba.xlsx", 2, 0);
   		StringBuilder dia = new StringBuilder(String.valueOf(numEntero));
   		dia.deleteCharAt(2);
   		dia.deleteCharAt(2);
   		String resultString = dia.toString();
   		Melissa.findElement(By.xpath("//td[contains(text(),'"+(resultString)+"')]")).click();
    }*/
	
	public static void seleccionarCantidadPersonas() throws InterruptedException {
		Melissa.findElement(elegirCantidadDePersonas).click();
		Thread.sleep(5000);
	}
	
	 public static void seleccionarCantidadDeAdultos() throws IOException{
		 //Le damos el valor numero a leer en el archivo externo de excel
    	 numEntero=  leerArchivo.getNumericCellValue("DatosBooking", "C:\\Users\\semillero\\Documents\\Prueba.xlsx", 2, 0);
    	 //Realizamos la condicion para que valide la cantidad de adultos y le de click
    	     for (int i = 3; i<=numEntero;i=i+1) {
    	     Melissa.findElement(cantidadDeAdultos).click();
    	     }
     }
	 
	 public static void selecionarCantidadDeNi�os() throws IOException{
		//Le damos el valor numero a leer en el archivo externo de excel
		 numEntero=  leerArchivo.getNumericCellValue("DatosBooking", "C:\\Users\\semillero\\Documents\\Prueba.xlsx", 3, 0);
		//Realizamos la condicion para que valide la cantidad de ni�os y le de click
	     for (int i = 1; i<=numEntero;i=i+1) {
	     Melissa.findElement(cantidadDeNi�os).click();
	     }
	 }
	 
	 public static void seleccionarEdadDelNi�o() {
		 //Creamos una lista para elegir la edad del ni�o
		 List<WebElement> listOfElements = Melissa.findElements (By.xpath ("//select[contains(@name,'age')]"));
    	 listOfElements.get(0).click();
	 }
	 
	 public static void cantidaHabitaciones() throws IOException {
		//Le damos el valor numero a leer en el archivo externo de excel
		 numEntero=  leerArchivo.getNumericCellValue("DatosBooking", "C:\\Users\\semillero\\Documents\\Prueba.xlsx", 4, 0);
		//Realizamos la condicion para que valide la cantidad de habitaciones y le de click
	     for (int i = 1; i<=numEntero;i=i+1) {
	    	 Melissa.findElement(cantidadHabitaciones).click();
	     }
	 }
	
	public static void darClickEnElBotonBuscar() throws InterruptedException {
		Melissa.findElement(clickEnElBotonBuscar).click();
		Thread.sleep(5000);
	}
	
	public static void seleccionarOpcionAlojamiento() throws InterruptedException {
		//creamos un objeto webelement y le decimos que le de clic cuando el elemento sea visible 
		WebElement txt= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Oh! Cancun - The Urban Oasis')]")));
		js.executeScript("arguments[0].scrollIntoView();", txt);
		Melissa.findElement(seleccionarElHotel).click();
		Thread.sleep(5000);
	}
	
	 public static void cerrarNavegador() {
		 //cerramos la ventana del navegador 
    	 Melissa.close();
     }
    
	
	
	
	
	
	
	
	
	
	
	
	
	/*public static void seleccionarAlojamiento() throws InterruptedException {
		WebElement tiempo= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[starts-with(@class='hprt-reservation-cta')]")));
		js.executeScript("arguments[0].scrollIntoView();", tiempo);
		Melissa.findElement(elegirHabitacion).click();
		
	}*/
	
	/*public static void seleccionarCantidadHabitaciones() {
		List<WebElement> lista=Melissa.findElements(By.className("hprt-nos-select"));
		Select habitacion = new Select(lista.get(0));
		habitacion.selectByValue("1");
		
		
	}*/
	
	
	

}
