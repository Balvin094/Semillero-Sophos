package POMBooking;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcelFile {
	
	//Escribir una lista de datos 
	public void WriteExcelFile(String filepath,String sheetName,String[] dataToWrite) throws IOException {
		
		//El camino donde va estar el fichero
		File file = new File(filepath);
		
		//Leer los datos del archivo
		FileInputStream inputStream = new FileInputStream(file);
		
		//Donde se guarda el libro de excel, el fichero como tal. el inputStream el archivo de los datos
		XSSFWorkbook newWorbook =new XSSFWorkbook(inputStream);
		
		//El objeto donde se guarda la hoja donde se trabaja
		XSSFSheet newSheet = newWorbook.getSheet(sheetName);
		
		//Cantidad de filas que existen
		int rowCount = newSheet.getLastRowNum()-newSheet.getFirstRowNum();
		
		//apartir de la ultima fila
		 XSSFRow row = newSheet.getRow(0);
		 
		 //Crear una nueva fila
		 XSSFRow newRow = newSheet.getRow(rowCount+1);
		 
		 //Contar por la fila de arriba
		 for (int i = 0; i < row.getLastCellNum(); i++) {
		
		//nueva celda
		XSSFCell newCell = newRow.createCell(i);
		
		//El arreglo que se resive en los parametros del metodo
		newCell.setCellValue(dataToWrite[i]);
		 }
		 
		 //Cerramos los parametros del metodo
		 inputStream.close();
		 
		 //Escribir la informacion en el excel
		 FileOutputStream outputSream = new FileOutputStream(file);
		 
		 //Se le pasa la informacion
		 newWorbook.write(outputSream);
		 
		 //Cerramos
		 outputSream.close();
	}
	
	//crear un valor en una celda expecifica 
	public void writeCellValue(String filepath,String sheetName,int rowNumber,int cellNumber,String resultText) throws IOException {
		
		//El camino donde va estar el fichero
		File file = new File(filepath);
		
		//Leer los datos del archivo
		FileInputStream inputStream = new FileInputStream(file);
		
		//Donde se guarda el libro de excel, el fichero como tal. el inputStream el archivo de los datos
		XSSFWorkbook newWorbook =new XSSFWorkbook(inputStream);
		
		//El objeto donde se guarda la hoja donde se trabaja
		XSSFSheet newSheet = newWorbook.getSheet(sheetName);
		
		//Crear una nueva fila
		XSSFRow row = newSheet.getRow(rowNumber);
		
		//Referencia alas primeras celdas, y el numero hace referencia a la 2 celda donde va estar el resultado
		 XSSFCell firstCell = row.getCell(cellNumber-1);
		 
		 //Enviar a la consola el valor de la primera celda
		 System.out.print("first cell value is:"+ firstCell.getStringCellValue());
		 
		 //Creacion de celda 
		 XSSFCell nextCell= row.createCell(cellNumber);
		 
		 //Siguiente celda
		 nextCell.setCellValue(resultText);
		
		 //Enviar a la consola el valor de la celda
		 System.out.print("next cell value is:"+ nextCell.getStringCellValue());
		 
		 //Cerrar
		 inputStream.close();
		 
		 //para escribir la informacion
		 FileOutputStream outputSream = new FileOutputStream(file);
		 newWorbook.write(outputSream);
		 outputSream.close();
	}

}
