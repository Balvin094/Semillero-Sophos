package MisUtilidades;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class Utilidades {
	
	 WebDriver Melissa;
	 
	 
	 public void AbrirNavegador(String url, WebDriver Meli ) {
		 Meli.get(url);
		 	
	}
	 
	 public void BuscarElementoSendKeys(String path, String texto, WebDriver Meli) {
		 Meli.findElement(By.xpath(path)).sendKeys(texto);
		 
	 }
	 
	 public void HacerClick (String path, WebDriver Meli) {
		 Meli.findElement(By.xpath(path)).click();
		 
	 }
	  public void ByName (String name, WebDriver Meli) {
		  Meli.findElement(By.name(name)).sendKeys(Keys.ENTER);
	  }
	  
	 
	 
	 /*public void  IniciarGrabacion (String rutavideo, WebDriver Meli) throws IOException, ATUTestRecorderException {
		 DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		 Date date = new Date();
		 ATUTestRecorder grabar = new ATUTestRecorder(rutavideo,"TestVideo-"+dateFormat.format(date),false);
		 grabar.start();
		 	 
	 }*/
	 
	 public static ATUTestRecorder IniciarGrabacion() throws ATUTestRecorderException {
		 DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		 Date date = new Date();
		 ATUTestRecorder recorder = new ATUTestRecorder ("C:\\Selenium\\ScriptVideos\\","TestVideo-"+dateFormat.format(date),false);
		 recorder.start();
		 
		 return recorder;
	 }
	 
	  public static void FinalizarGrabacion(ATUTestRecorder recorder) throws ATUTestRecorderException{
	  	
	  	recorder.stop();
	  }
	 
	/* public void FinalizarGrabacion (String rutavideo, WebDriver Meli) throws IOException, ATUTestRecorderException {
		 DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		 Date date = new Date();
		 ATUTestRecorder grabar = new ATUTestRecorder(rutavideo,"TestVideo-"+dateFormat.format(date),false);
		 grabar.stop();
		 
		 
	 }*/

	public void TomarFoto(String ruta, WebDriver Meli) throws IOException {
		WebDriver Melissa= Meli;
		DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		Date date = new Date();
		File scrFile = ((TakesScreenshot)Melissa).getScreenshotAs(OutputType.FILE); 
		FileUtils.copyFile(scrFile, new File(ruta+"screenshot"+dateFormat.format(date)+".png"));
		
	}
	
	public void CerrarNavegador (WebDriver Melissa) {
		Melissa.quit();
		
	}
	
	public void MaximizarVentana (WebDriver Melissa) {
		Melissa.manage().window().maximize();
	}
	
	
}
