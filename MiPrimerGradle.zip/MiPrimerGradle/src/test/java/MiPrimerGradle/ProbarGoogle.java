package MiPrimerGradle;

import MisUtilidades.Utilidades;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ProbarGoogle {
	

	//Se declara el driver del navegador 
	 private WebDriver Melissa;
	 
	 ATUTestRecorder recorder;
	
	 
	@Before
	public void setUp() throws Exception {
		
		//Aqui se indica el navegador a usar 
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
				
		//Creamos el robot
		Melissa = new ChromeDriver();
				
		//assertNull("No esta nulo el objeto", Melissa);
		
		//Grabar video 
		/*Utilidades iniciovideo = new Utilidades();
		iniciovideo.IniciarGrabacion("C:\\Selenium\\ScriptVideos", Melissa);*/
		
		
		
	}

	@After
	public void tearDown() throws Exception {
		
		//Captura del test
		Utilidades foto = new Utilidades();
		foto.TomarFoto("C:\\tmp\\", Melissa);
		
		//Cerrar 
		Utilidades cerrar = new Utilidades();
		cerrar.CerrarNavegador(Melissa);
		
		
		//Detener video 
		/*Utilidades finalvideo = new Utilidades();
		finalvideo.FinalizarGrabacion("C:\\Selenium\\ScriptVideos", Melissa);*/
		
		
	}

	@Test
	public void test() throws InterruptedException,ATUTestRecorderException, IOException {
		
		ATUTestRecorder recorder = Utilidades.IniciarGrabacion();
		
		//maximizar la ventana del navegador
		Utilidades maximizar = new Utilidades();
		maximizar.MaximizarVentana(Melissa);
				
		//Abrir pagina 
		Utilidades abrir = new Utilidades();
		abrir.AbrirNavegador("http://www.google.com", Melissa);
		//Melissa.get();
				
		//Mapear los elementos de la apagina 
		Utilidades buscarsendkeys= new Utilidades();
		Utilidades click= new Utilidades();
		Utilidades pornombre= new Utilidades();

		buscarsendkeys.BuscarElementoSendKeys("//input[@name='q']", "pinterest", Melissa);
		pornombre.ByName("q", Melissa);
		click.HacerClick("//cite[contains(text(),'https://co.pinterest.com/')]", Melissa);
		buscarsendkeys.BuscarElementoSendKeys("//input[@id='email']", "balvinmelissa@gmail.com", Melissa);
		buscarsendkeys.BuscarElementoSendKeys("//input[@id='password']", "balvin", Melissa);
		

		Utilidades.FinalizarGrabacion(recorder);
		
				
		
	}
	

}
