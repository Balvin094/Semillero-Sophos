package POMPinterest;

//import static org.junit.Assert.assertThat;
//import static org.hamcrest.CoreMatchers.*;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class Pinterest {
	
	
	//Llamado del driver 
	static WebDriver Melissa;
	
	//Mapeo de la pagina 
	static By campodeBusqueda=By.xpath("//input[@name='q']");
	static By botonBuscar =By.name("q");
	static By seleccionarOpcion=By.xpath("//cite[contains(text(),'https://co.pinterest.com/')]");
	static By escribirEmail=By.xpath("//input[@id='email']");
	static By escribirContrase�a=By.xpath("//input[@id='password']");
	
	

	public static void abrirPaginaInicialDeGoogle() {
		
		//Damos la ubicacion del webdriver
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		//Creamos el robot
		 Melissa= new ChromeDriver();
		 //Maximiza la ventana
		 Melissa.manage().window().maximize();
		 //Vamos a la pagina ingresada
		 Melissa.get("http://www.google.com");
	}
	
	public static  void escribirEnElCampoDeBusqueda(String cadenabuscar) {
		//Ingresamos la palabra de busqueda 
		 Melissa.findElement(campodeBusqueda).sendKeys(cadenabuscar);
		 
	}
	
	public  static void darClickEnBotonBuscar() {
		//Damos clic en el boton
		Melissa.findElement(botonBuscar).sendKeys(Keys.ENTER);
		
	}
	
	public static void seleccionarLaPaginaBuscada() {
		//Seleccionamos la pagina buscada 
		Melissa.findElement(seleccionarOpcion).click();
	}
	
	public static void digitarCorreoEnElCampoEmail(String correo) {
		//Ingresamos el el correo
		Melissa.findElement(escribirEmail).sendKeys(correo);
	}
	
	//public static void validarEmail() {
		//String meli= Melissa.findElement(estudiantes/*campocomosedeclaro*/).getText();
		//assertThat(meli, is ("estudiantes"/*campocomosellamaenlapagina*/));
	
	
	public static void digitarContrase�aEnElCampoContrase�a(String contrase�a) {
		//Ingresamos la contrase�a
		Melissa.findElement(escribirContrase�a).sendKeys(contrase�a);
	}
	
	public static void tomarFotoDeEvidenciaDelTest(String rutafoto) throws IOException{
		//Creamos el objeto para la fecha y la hora de la captura de pantalla
		DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		//Creamos el objeto tipo date 
		Date date = new Date();
		//Tomamos la captura de pantalla y le damos la ubicacion donde va a guardar 
		File scrFile = ((TakesScreenshot)Melissa).getScreenshotAs(OutputType.FILE); 
		FileUtils.copyFile(scrFile, new File(rutafoto+"screenshot"+dateFormat.format(date)+".png"));
	}
	
	public static ATUTestRecorder iniciarGrabacionDelTest() throws ATUTestRecorderException {
		//Creamos el objeto para la fecha y la hora del video
		DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		Date date = new Date();
		//Comenzamos a grabar y le damos la ubicacion donde guardara video
		ATUTestRecorder recorder = new ATUTestRecorder ("C:\\Selenium\\ScriptVideos\\","TestVideo-"+dateFormat.format(date),false);
		recorder.start();
		 
		return recorder;
	}
	
	public static void finalizarGrabacionDelTest(ATUTestRecorder recorder) throws ATUTestRecorderException{
		//Termina la grabacion
	  	recorder.stop();
	  }
	 
	
	public static void cerrarVentanaNavegador(WebDriver driver) {
		//Cerramos la ventana del navegador 
		Melissa.quit();
	}
	
}
