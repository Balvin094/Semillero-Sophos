package POMPinterest;


import static POMPinterest.Pinterest.abrirPaginaInicialDeGoogle;
import static POMPinterest.Pinterest.darClickEnBotonBuscar;
import static POMPinterest.Pinterest.escribirEnElCampoDeBusqueda;
import static POMPinterest.Pinterest.seleccionarLaPaginaBuscada;
import static POMPinterest.Pinterest.digitarCorreoEnElCampoEmail;
import static POMPinterest.Pinterest.digitarContrase�aEnElCampoContrase�a;
import static POMPinterest.Pinterest.cerrarVentanaNavegador;
import static POMPinterest.Pinterest.tomarFotoDeEvidenciaDelTest;
import static POMPinterest.Pinterest.iniciarGrabacionDelTest;
import static POMPinterest.Pinterest.finalizarGrabacionDelTest;


import java.io.IOException;

import org.junit.Test;
import org.openqa.selenium.WebDriver;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class ProbarPinterest {

	static WebDriver Melissa;
	ATUTestRecorder recorder;

	@Test
	public void probarBusquedaConGoogle() throws IOException, ATUTestRecorderException,InterruptedException {
		
		recorder = iniciarGrabacionDelTest();
		abrirPaginaInicialDeGoogle();
		escribirEnElCampoDeBusqueda("Pinterest");
		darClickEnBotonBuscar();
		seleccionarLaPaginaBuscada();
		digitarCorreoEnElCampoEmail("balvinmelissa@gmail.com");
		digitarContrase�aEnElCampoContrase�a("balvin");
		tomarFotoDeEvidenciaDelTest("C:\\capturas\\");
		cerrarVentanaNavegador(Melissa);
		finalizarGrabacionDelTest(recorder);
		
		
	}

}
